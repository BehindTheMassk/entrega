from django import forms
from .models import Subasta

class SubastaForm(forms.ModelForm):
    class Meta:
        model = Subasta
        fields = ['nombre', 'descripcion', 'imagen', 'descripcion_detallada', 'precio_inicial']
