from django.apps import AppConfig

class RayomacuinAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rayomacuin_app'  # Asegúrate de que 'rayomacuin_app' coincida con el nombre de tu aplicación
