from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login as auth_login, authenticate
from django.contrib import messages   
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.db import transaction
from .models import Subasta, Carrito, Item
from django.contrib.auth import logout
from django.shortcuts import redirect

def index(request):
    """Renderiza la página de inicio."""
    return render(request, 'rayotemplates/index.html')

def inicio(request):
    """Renderiza la página de inicio secundaria."""
    return render(request, 'rayotemplates/inicio.html')

def servicios(request):
    """Renderiza la página de servicios."""
    return render(request, 'rayotemplates/servicios.html')

def galeria(request):
    """Renderiza la página de galería."""
    return render(request, 'rayotemplates/galeria.html')

def contacto(request):
    """Renderiza la página de contacto."""
    return render(request, 'rayotemplates/contacto.html')

def logout_view(request):
    logout(request)
    # Redirigir a la página de inicio u otra página después de cerrar sesión
    return redirect('index')  # Asegúrate de tener una URL llamada 'index' definida en tus URLs


def login(request):
    # Lógica para la vista de login
    return render(request, 'rayotemplates/login.html')

def subastas_list(request):
    """Renderiza la página de listado de subastas."""
    subastas = Subasta.objects.all()
    return render(request, 'rayotemplates/subastas.html', {'subastas': subastas})

def subasta_detail(request, uuid):
    """Renderiza la página de detalle de una subasta."""
    subasta = get_object_or_404(Subasta, uuid=uuid)
    return render(request, 'rayotemplates/subasta_detail.html', {'subasta': subasta})

@login_required
def carrito(request):
    """Muestra el contenido del carrito del usuario."""
    carrito = Carrito.objects.filter(usuario=request.user).prefetch_related('items__subasta').first()
    total_carrito = sum(item.subasta.precio * item.cantidad for item in carrito.items.all()) if carrito else 0
    return render(request, 'rayotemplates/carrito.html', {'carrito': carrito, 'total_carrito': total_carrito})


@login_required
def agregar_al_carrito(request, uuid):
    """Agrega un item al carrito del usuario."""
    subasta = get_object_or_404(Subasta, uuid=uuid)
    carrito, created = Carrito.objects.get_or_create(usuario=request.user)
    item, item_created = Item.objects.get_or_create(carrito=carrito, subasta=subasta)
    if not item_created:
        item.cantidad += 1
        item.save()
    return redirect('carrito')


@login_required
def actualizar_cantidad(request, item_id):
    """Actualiza la cantidad de un item en el carrito del usuario."""
    item = get_object_or_404(Item, id=item_id, carrito__usuario=request.user)
    if request.method == 'POST':
        cantidad = int(request.POST.get('cantidad', 1))
        item.cantidad = cantidad
        item.save()
    return redirect('carrito')

@login_required
def eliminar_item(request, item_id):
    """Elimina un item del carrito del usuario."""
    item = get_object_or_404(Item, id=item_id, carrito__usuario=request.user)
    item.delete()
    return redirect('carrito')

@login_required
def vaciar_carrito(request):
    """Vacía el carrito del usuario."""
    carrito = get_object_or_404(Carrito, usuario=request.user)
    carrito.vaciar_carrito()
    return redirect('carrito')

@login_required
def checkout(request):
    """Muestra la página de checkout."""
    return render(request, 'rayotemplates/checkout.html')

def register(request):
    """Muestra la página de registro y maneja el registro de usuarios."""
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()  # Guarda el usuario en la base de datos
            username = form.cleaned_data.get('username')
            messages.success(request, f'Cuenta creada para {username}. Puedes iniciar sesión ahora.')
            return redirect('login')  # Redirige a la página de inicio de sesión después del registro
    else:
        form = UserCreationForm()
    return render(request, 'rayotemplates/register.html', {'form': form})   