from django.urls import path, include
from . import views
from django.contrib.auth import views as auth_views
from rayomacuin_app import views    

urlpatterns = [
    path('', views.index, name='index'),
    path('inicio/', views.inicio, name='inicio'),
    path('servicios/', views.servicios, name='servicios'),
    path('galeria/', views.galeria, name='galeria'),
    path('contacto/', views.contacto, name='contacto'),
    
    # Subastas
    path('subastas/', views.subastas_list, name='subastas'),
    path('subastas/<uuid:uuid>/', views.subasta_detail, name='subasta_detail'),
    
      # Carrito
    path('carrito/', views.carrito, name='carrito'),
    path('carrito/agregar/<uuid:uuid>/', views.agregar_al_carrito, name='agregar_al_carrito'),
    path('carrito/eliminar/<uuid:item_id>/', views.eliminar_item, name='eliminar_item'),
    path('carrito/vaciar/', views.vaciar_carrito, name='vaciar_carrito'),
    
    
    # Checkout
    path('checkout/', views.checkout, name='checkout'),
    
    # Autenticación
    path('login/', auth_views.LoginView.as_view(template_name='rayotemplates/login.html'), name='login'),
    path('login/', views.login, name='login'), 
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('register/', views.register, name='register'),
]
