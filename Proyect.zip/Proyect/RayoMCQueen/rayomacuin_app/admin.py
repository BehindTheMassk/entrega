from django.contrib import admin
from .models import Subasta,Contacto_ad
# Register your models here.
class ProductoAdmin(admin.ModelAdmin):
    list_display = ["nombre","precio","nuevo","marca"]
    list_editable = ["precio"]
    search_fields = ["nombre"]
    list_filter = ["marca", "nuevo"]
    list_per_page = [1]

    admin.site.register(Contacto_ad)
    admin.site.register(Subasta)