from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
import uuid

class Subasta(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    rendimiento_hp = models.CharField(max_length=50, blank=True, null=True)
    aceleracion = models.CharField(max_length=50, blank=True, null=True)
    velocidad_maxima = models.CharField(max_length=50, blank=True, null=True)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    codigo = models.CharField(max_length=10, unique=True, blank=True, null=True, editable=True)

    def __str__(self):
        return self.nombre

    def clean(self):
        if self.precio <= 0:
            raise ValidationError(_('El precio debe ser un valor positivo.'))

    def save(self, *args, **kwargs):
        self.clean()
        if not self.codigo:
            self.codigo = self.generate_unique_code()
        super().save(*args, **kwargs)

    def generate_unique_code(self):
        return str(uuid.uuid4())[:10]

class Carrito(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE, related_name='carrito')
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Carrito de {self.usuario.username}"

    def get_total(self):
        total = sum(item.get_total() for item in self.items.all())
        if total < 0:
            raise ValidationError('El total del carrito no puede ser negativo.')
        return total

    def vaciar_carrito(self):
        self.items.all().delete()

class Item(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE, related_name='items')
    subasta = models.ForeignKey(Subasta, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.cantidad} x {self.subasta.nombre}"

    def get_total(self):
        total = self.subasta.precio * self.cantidad
        if total < 0:
            raise ValidationError('El total del ítem no puede ser negativo.')
        return total

    def clean(self):
        if self.cantidad <= 0:
            raise ValidationError('La cantidad debe ser mayor que cero.')

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

  
opciones_consulta = [
    [0, "consulta"],
    [1, "reclamo"],
    [2, "sugerencia"],
    [3, "felicitaciones"]
]


class Contacto_ad(models.Model):
    nombre = models.CharField(max_length=30)
    correo = models.EmailField()
    tipo_consulta = models.IntegerField(choices=opciones_consulta)
    mensaje =models.TextField()
    avisos = models.BooleanField()

    def ___str__(self):
        return self.nombre