from rayomacuin_app.models import Subasta
import uuid
import django
import sys
import os

# Añadir la carpeta del proyecto a sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importar los modelos
from rayomacuin_app.models import Subasta


# Establecer la variable de entorno DJANGO_SETTINGS_MODULE
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'RayoMCQueen.settings')

# Inicializar Django
django.setup()


# Datos de las subastas
subastas = [
    {"nombre": "Audi e-tron GT", "descripcion": "2023 Audi e-tron GT.", "rendimiento_hp": "469", "aceleracion": "3.9s", "velocidad_maxima": "152 mph", "precio": 100000.00},
    {"nombre": "BMW iX M60", "descripcion": "2022 BMW iX M60.", "rendimiento_hp": "610", "aceleracion": "3.6s", "velocidad_maxima": "155 mph", "precio": 95000.00},
    {"nombre": "Porsche 911 GT3 RS", "descripcion": "2024 Porsche 911 GT3 RS.", "rendimiento_hp": "518", "aceleracion": "3.2s", "velocidad_maxima": "197 mph", "precio": 180000.00},
    {"nombre": "Tesla Model S Plaid", "descripcion": "2025 Tesla Model S Plaid.", "rendimiento_hp": "1020", "aceleracion": "1.99s", "velocidad_maxima": "200 mph", "precio": 130000.00},
    {"nombre": "Mercedes-Benz EQS", "descripcion": "2023 Mercedes-Benz EQS.", "rendimiento_hp": "516", "aceleracion": "4.1s", "velocidad_maxima": "130 mph", "precio": 90000.00},
    {"nombre": "Ferrari SF90 Stradale", "descripcion": "2024 Ferrari SF90 Stradale.", "rendimiento_hp": "986", "aceleracion": "2.5s", "velocidad_maxima": "211 mph", "precio": 500000.00},
    {"nombre": "Lamborghini Huracán Evo RWD", "descripcion": "2025 Lamborghini Huracán Evo RWD.", "rendimiento_hp": "610", "aceleracion": "2.9s", "velocidad_maxima": "202 mph", "precio": 200000.00},
    {"nombre": "McLaren Artura", "descripcion": "2023 McLaren Artura.", "rendimiento_hp": "671", "aceleracion": "3.0s", "velocidad_maxima": "205 mph", "precio": 225000.00},
    {"nombre": "Aston Martin Valkyrie", "descripcion": "2024 Aston Martin Valkyrie.", "rendimiento_hp": "1160", "aceleracion": "2.6s", "velocidad_maxima": "250 mph", "precio": 3000000.00},
    {"nombre": "Bugatti Chiron Super Sport", "descripcion": "2025 Bugatti Chiron Super Sport.", "rendimiento_hp": "1578", "aceleracion": "2.4s", "velocidad_maxima": "273 mph", "precio": 3900000.00},
    {"nombre": "Rolls-Royce Spectre", "descripcion": "2023 Rolls-Royce Spectre.", "rendimiento_hp": "577", "aceleracion": "4.4s", "velocidad_maxima": "155 mph", "precio": 400000.00},
    {"nombre": "Koenigsegg Jesko", "descripcion": "2024 Koenigsegg Jesko.", "rendimiento_hp": "1600", "aceleracion": "2.5s", "velocidad_maxima": "300 mph", "precio": 2800000.00},
]

# Inserta los datos en la base de datos
for subasta in subastas:
    nueva_subasta = Subasta(
        uuid=uuid.uuid4(),
        nombre=subasta["nombre"],
        descripcion=subasta["descripcion"],
        rendimiento_hp=subasta.get("rendimiento_hp", ""),
        aceleracion=subasta.get("aceleracion", ""),
        velocidad_maxima=subasta.get("velocidad_maxima", ""),
        precio=subasta["precio"]
    )
    nueva_subasta.save()

print("Datos de subastas insertados correctamente.")
