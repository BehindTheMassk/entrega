# RayoMCQueen_/urls.py
from django.contrib import admin
from django.urls import path, include
from rayomacuin_app import views  # Importa las vistas de tu aplicación

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='base'),  # Ruta para la página principal del sitio (URL raíz)
    path('login/', views.login, name='login'),
    path('rayomacuin/', include('rayomacuin_app.urls')),  # Incluye las URLs de rayomacuin_app
    path('rayomacuin/subastas/', include('subastas.urls')),  # Incluye las URLs de subastas
]
