# subastas/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Vehiculo
from .forms import VehiculoForm

def vehiculos_list(request):
    vehiculos = Vehiculo.objects.all()
    return render(request, 'subastas_templates/vehiculos_list.html', {'vehiculos': vehiculos})

def vehiculo_detail(request, uuid):
    vehiculo = get_object_or_404(Vehiculo, uuid=uuid)
    return render(request, 'subastas_templates/vehiculo_detail.html', {'vehiculo': vehiculo})

def vehiculo_nuevo(request):
    if request.method == 'POST':
        form = VehiculoForm(request.POST, request.FILES)
        if form.is_valid():
            vehiculo = form.save()
            return redirect('vehiculo_detail', uuid=vehiculo.uuid)
    else:
        form = VehiculoForm()
    return render(request, 'subastas_templates/vehiculo_nuevo.html', {'form': form})

def vehiculo_editar(request, uuid):
    vehiculo = get_object_or_404(Vehiculo, uuid=uuid)
    if request.method == 'POST':
        form = VehiculoForm(request.POST, request.FILES, instance=vehiculo)
        if form.is_valid():
            vehiculo = form.save()
            return redirect('vehiculo_detail', uuid=vehiculo.uuid)
    else:
        form = VehiculoForm(instance=vehiculo)
    return render(request, 'subastas_templates/vehiculo_editar.html', {'form': form, 'vehiculo': vehiculo})

def vehiculo_eliminar(request, uuid):
    vehiculo = get_object_or_404(Vehiculo, uuid=uuid)
    if request.method == 'POST':
        vehiculo.delete()
        return redirect('vehiculos_list')
    return render(request, 'subastas_templates/vehiculo_eliminar.html', {'vehiculo': vehiculo})
