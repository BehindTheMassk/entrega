# subastas/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.vehiculos_list, name='vehiculos_list'),
    path('crear/', views.vehiculo_nuevo, name='vehiculo_nuevo'),
    path('<uuid:uuid>/', views.vehiculo_detail, name='vehiculo_detail'),
    path('editar/<uuid:uuid>/', views.vehiculo_editar, name='vehiculo_editar'),
    path('eliminar/<uuid:uuid>/', views.vehiculo_eliminar, name='vehiculo_eliminar'),
]
