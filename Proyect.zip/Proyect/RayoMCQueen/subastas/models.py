from django.db import models

# Create your models here.
from django.db import models
from uuid import uuid4

class Vehiculo(models.Model):
    uuid = models.UUIDField(default=uuid4, editable=False, unique=True)
    marca = models.CharField(max_length=100)
    modelo = models.CharField(max_length=100)
    anio = models.PositiveIntegerField()
    kilometraje = models.PositiveIntegerField()
    precio_inicial = models.DecimalField(max_digits=10, decimal_places=2)
    imagen = models.ImageField(upload_to='vehiculos/')
    descripcion = models.TextField()

    def __str__(self):
        return f"{self.marca} {self.modelo} ({self.anio})"
