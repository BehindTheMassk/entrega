from django.contrib import admin
from .models import Vehiculo

# Register your models here.
class VehiculoAdmin(admin.ModelAdmin):
    list_display = ["marca", "modelo", "anio", "kilometraje", "precio_inicial"]

admin.site.register(Vehiculo, VehiculoAdmin)
